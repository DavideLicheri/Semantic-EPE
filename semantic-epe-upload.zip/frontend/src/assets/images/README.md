# Assets - Immagini

## Logo EPE

Posiziona qui il logo EPE con il nome `epe-logo.png` (o altro formato supportato).

### Specifiche Consigliate:
- **Formato**: PNG con sfondo trasparente (preferito) o SVG
- **Dimensioni**: Minimo 200x200px per qualità ottimale
- **Colori**: Il CSS applicherà automaticamente filtri per renderlo bianco su sfondo scuro
- **Nome file**: `epe-logo.png` (o aggiorna il path in App.tsx)

### Formati Supportati:
- PNG (raccomandato per loghi con trasparenza)
- SVG (ottimo per scalabilità)
- JPG (se non serve trasparenza)
- WebP (per ottimizzazione)

### Posizionamento Attuale:
Il logo è configurato per apparire:
- A sinistra del titolo nell'header
- Altezza: 60px (desktop), 50px (mobile)
- Colore: Automaticamente convertito in bianco per contrasto

### Alternative di Layout:
Vedi `App-logo-centered.css.example` per altre opzioni di posizionamento:
- Logo centrato sopra il titolo
- Logo a sinistra con testo allineato a sinistra
- Dimensioni diverse per diversi layout