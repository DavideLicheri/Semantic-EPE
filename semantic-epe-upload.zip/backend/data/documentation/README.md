# EURING Documentation

This directory contains the official EURING documentation used to build the SKOS model.

## Structure

- `version_specs/` - Official specifications for each EURING version
- `conversion_notes/` - Documentation about conversion between versions
- `analysis/` - Our analysis and extracted information

## Versions

- **1966**: First EURING code version
- **1979**: Updated version with expanded fields
- **2000**: Major revision with new format
- **2020**: Current version with pipe-delimited format

## Usage

The documentation in this directory is used to:
1. Define precise field definitions in SKOS models
2. Create accurate parsing rules
3. Implement conversion algorithms
4. Validate against real EURING strings