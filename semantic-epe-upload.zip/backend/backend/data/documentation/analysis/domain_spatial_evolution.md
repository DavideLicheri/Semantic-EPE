# Spatial Domain Evolution

**Description**: Geographic coordinates, location accuracy, and spatial encoding systems for recording bird locations

## Field Evolution Details

## Compatibility Matrix

| From \ To | 
|-----------|

