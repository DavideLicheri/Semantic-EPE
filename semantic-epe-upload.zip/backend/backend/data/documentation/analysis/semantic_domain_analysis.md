# EURING Semantic Domain Analysis

This document provides a comprehensive analysis of the 7 semantic domains across all EURING code versions (1966-2020).

## Executive Summary

- **Total Versions Analyzed**: 0
- **Total Fields Analyzed**: 0
- **Semantic Domains**: 7
- **Analysis Period**: 1966-2020 (54 years of evolution)

## Semantic Domains Overview

### Identification Marking
**Description**: Ring numbers, schemes, metal rings, other marks, and verification systems for unique bird identification throughout its life

**Total Fields**: 0

**Fields in this domain**:

### Species
**Description**: Species codes, taxonomy systems, and identification verification by both finders and ringing schemes

**Total Fields**: 0

**Fields in this domain**:

### Demographics
**Description**: Age and sex classification systems based on plumage characteristics and morphological features

**Total Fields**: 0

**Fields in this domain**:

### Temporal
**Description**: Date and time formats for recording capture, observation, and handling events

**Total Fields**: 0

**Fields in this domain**:

### Spatial
**Description**: Geographic coordinates, location accuracy, and spatial encoding systems for recording bird locations

**Total Fields**: 0

**Fields in this domain**:

### Biometrics
**Description**: Physical measurements including wing length, weight, bill dimensions, tarsus, fat scores, muscle condition, and moult status

**Total Fields**: 0

**Fields in this domain**:

### Methodology
**Description**: Capture methods, handling conditions, manipulation status, lures used, and procedural information

**Total Fields**: 0

**Fields in this domain**:

## Evolution Timeline

