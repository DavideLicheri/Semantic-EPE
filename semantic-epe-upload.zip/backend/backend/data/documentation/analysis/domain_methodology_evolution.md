# Methodology Domain Evolution

**Description**: Capture methods, handling conditions, manipulation status, lures used, and procedural information

## Field Evolution Details

## Compatibility Matrix

| From \ To | 
|-----------|

