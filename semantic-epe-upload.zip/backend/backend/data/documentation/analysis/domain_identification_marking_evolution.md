# Identification Marking Domain Evolution

**Description**: Ring numbers, schemes, metal rings, other marks, and verification systems for unique bird identification throughout its life

## Field Evolution Details

## Compatibility Matrix

| From \ To | 
|-----------|

